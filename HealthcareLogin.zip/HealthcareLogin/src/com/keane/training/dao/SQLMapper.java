package com.keane.training.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.keane.dbfw.ResultMapper;
import com.keane.training.domain.Rented;
import com.keane.training.domain.User;
import com.keane.training.domain.Vehicle;

public class SQLMapper {
	public static final String INSERTUSER="insert into Health_care values(myseq.nextval,?,?,?,?,?,?,?,?,?,?)";

	//public static final String BOOKAPPOINTMENT="INSERT INTO Health_care values(?,?,?,?,?,?)";
	
	public static final String CHECKLOGIN="select * from Health_care where id=? "; 
	
	public static final String CHECKLOGIN1="select * from Health_care where id=? ";
	
	public static final ResultMapper USERMAPPER=
			new ResultMapper()
		{

		
			public Object mapRow(ResultSet rs) throws SQLException {
			String id=rs.getString(1);
			String name=rs.getString(2);
			String email=rs.getString(3);
			String password=rs.getString(4);
			String reenterpass=rs.getString(5);
			String gender=rs.getString(6);
			String dob=rs.getString(7);
			String bloodgroup=rs.getString(8);
			String mobileno=rs.getString(9);
			String address=rs.getString(10);
			int rno=rs.getInt(11);
			
			User c=new User(id,name,email,password,reenterpass,gender,dob,bloodgroup,mobileno,address,rno);
				return c;
			}//mapRow
			
		};
						
		
}



