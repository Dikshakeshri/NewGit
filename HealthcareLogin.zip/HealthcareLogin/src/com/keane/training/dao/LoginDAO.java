package com.keane.training.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.keane.dbcon.ConnectionHolder;
import com.keane.dbcon.DBConnectionException;
import com.keane.dbfw.DBFWException;
import com.keane.dbfw.DBHelper;
import com.keane.dbfw.ParamMapper;

public class LoginDAO {
	static Logger log = Logger.getLogger(LoginDAO.class);

	public List validateLogin(final String id,final int rno,final String password) throws DAOAppException {
		List res = null;
		ConnectionHolder ch = null;
		Connection con = null;
		System.out.println("Entered DAAO fucntion");
		try {
			System.out.println("enetr !!!!!!!!!!!!!!!!!!!!!!!!!!");
			ch = ConnectionHolder.getInstance();
			System.out.println("ENteres try first statemnt");
			System.out.println(ch);
			con = ch.getConnection();
			ParamMapper paramMapper = new ParamMapper() {

				@Override
				public void mapParam(PreparedStatement pStmt)
						throws SQLException {
					System.out.println("Entered mapparam second inside try");
					pStmt.setInt(1, rno);
					pStmt.setString(2, id);
					pStmt.setString(3, password);
					System.out.println("entered inside mapparam");
				}
			};
			
			res = DBHelper.executeSelect(con, SQLMapper.CHECKLOGIN,
					paramMapper, SQLMapper.USERMAPPER);
			System.out.println(res);
		} catch (DBConnectionException e) {
			log.error(e);
			throw new DAOAppException(e);
		} catch (DBFWException e) {
			throw new DAOAppException(e);
		}
		return res;

	}	
}
