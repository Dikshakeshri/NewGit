package com.keane.training.domain;

import java.sql.Time;
import java.util.Date;

public class Appointment {
	private String id;
	private String pname;
	private String email;
	private int phoneno;
	private Date date;
	private Time time;
	public Appointment(String id, String pname, String email, int phoneno, Date date, Time time) {
		super();
		this.id = id;
		this.pname = pname;
		this.email = email;
		this.phoneno = phoneno;
		this.date = date;
		this.time = time;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(int phoneno) {
		this.phoneno = phoneno;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Time getTime() {
		return time;
	}
	public void setTime(Time time) {
		this.time = time;
	}
	@Override
	public String toString() {
		return "BookAppointment [id=" + id + ", pname=" + pname + ", email=" + email + ", phoneno=" + phoneno
				+ ", date=" + date + ", time=" + time + "]";
	}
	
}
