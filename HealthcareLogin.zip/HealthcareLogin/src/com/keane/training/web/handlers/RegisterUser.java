package com.keane.training.web.handlers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import com.keane.mvc.HttpRequestHandler;
import com.keane.training.dao.DAOAppException;
import com.keane.training.dao.RegisterDAO;
import com.keane.training.domain.User;

public class RegisterUser implements HttpRequestHandler {
	static Logger log = Logger.getLogger(RegisterUser.class);

	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException,NumberFormatException {
		//System.out.println(" I am SERVLET");
		PrintWriter out = response.getWriter();
		RegisterDAO dao = new RegisterDAO();
	    User user = new User();
		user.setName(request.getParameter("name"));
		user.setEmail(request.getParameter("email"));
		user.setPassword(request.getParameter("password"));
		user.setReenterpass(request.getParameter("reenterpass"));
		user.setGender(request.getParameter("gender"));
		user.setDob(request.getParameter("dob"));
		user.setBloodgroup(request.getParameter("bloodgroup"));
		user.setMobileno(request.getParameter("mobileno"));
		user.setAddress(request.getParameter("address"));
		user.setRno(Integer.parseInt(request.getParameter("rno")));
		boolean isExists;
		try {
			isExists = dao.validateUser(user.getId());

			if (isExists) {
				log.info("User already registered");
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("..\\Pages\\register.jsp");
				request.setAttribute("Err",
						"User already registered with the system");
				dispatcher.forward(request, response);
			} else {
				/*user.setPassword("NttData@"
						+ Integer.toString(user.getUid()));*/
				int finalRes = dao.registerUser(user);
				if (finalRes > 0) {

					RequestDispatcher dispatcher = request
							.getRequestDispatcher("..\\Pages\\success.jsp");
					request.setAttribute("success",
							"User succesfully registered with the system");
					request.setAttribute("details", user);
					dispatcher.forward(request, response);
				}
			}
		} catch (DAOAppException e) {
			RequestDispatcher dispatcher = request
					.getRequestDispatcher("error.jsp");
			request.setAttribute("Err", e.getMessage());
			dispatcher.forward(request, response);
		}
	}
}

